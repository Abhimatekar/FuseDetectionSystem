from tkinter import *
from tkinter.ttk import *
import os
import numpy as np
import cv2
from PIL import ImageTk, Image
from imutils.object_detection import non_max_suppression


def main():
    main_win = Tk()
    main_win.geometry("500x500")
    main_win.title("Fuse Detection System")
    stop_btn = Button(main_win, text="Stop", command=main_win.destroy).place(x=50, y=300)
    stop_lbl = Label(main_win, text="Stops this program").place(x=200, y=302)
    run_btn = Button(main_win, text="run", command=display).place(x=50, y=100)
    run_lbl = Label(main_win, text="Run all the images and match against Template").place(x=200, y=102)
    load_btn = Button(main_win, text="load", command=loadimage).place(x=50, y=200)
    load_lbl = Label(main_win, text="load first image").place(x=200, y=202)

    main_win.mainloop()

def display():
    path = "Fuse"
    images = os.listdir(path)
    temppath = r"D:\AbhiPy\CS50FinalProject\temp\template1.bmp"
    tempath2 = r"D:\AbhiPy\CS50FinalProject\temp\template2.bmp"
    for img in images: 
        img_rgb = cv2.imread(os.path.join(path, img))
        original_image= img_rgb
        gray= cv2.cvtColor(img_rgb,cv2.COLOR_BGR2GRAY)
        ret, thresh1 = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY_INV)
        edges= cv2.Canny(thresh1, 10,255, apertureSize=5)
        contours, hierarchy= cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        def get_contour_areas(contours):
            all_areas= []
            for cnt in contours:
                area= cv2.contourArea(cnt)
                all_areas.append(area)
            return all_areas
        sorted_contours= sorted(contours, key=cv2.contourArea, reverse= True)
        largest_item= sorted_contours[0]
        rect = cv2.minAreaRect(largest_item)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        a = 0
        if rect[2]<=5:
            a = 0
        elif 5 <= rect[2] <= 50:
            a = rect[2]
        else:
            a = rect[2]-90
        (h, w) = original_image.shape[:2]
        (cX, cY) = (w // 2, h // 2)
        # rotate our image by 45 degrees around the center of the image
        M = cv2.getRotationMatrix2D((cX, cY), a, 1.0)
        rotated = cv2.warpAffine(original_image, M, (w, h))

        temp = cv2.imread(temppath)
        temp2 = cv2.imread(tempath2)
        W, H = temp.shape[:2]

        # Define a minimum threshold
        thresh = 0.7

        # Converting them to grayscale
        img_gray = cv2.cvtColor(rotated,cv2.COLOR_BGR2GRAY)
        temp_gray = cv2.cvtColor(temp,cv2.COLOR_BGR2GRAY)
        temp2_gray = cv2.cvtColor(temp2,cv2.COLOR_BGR2GRAY)

        # Passing the image to matchTemplate method
        match = cv2.matchTemplate(image=img_gray, templ=temp_gray,method=cv2.TM_CCOEFF_NORMED)
        match2 = cv2.matchTemplate(image=img_gray, templ=temp2_gray,method=cv2.TM_CCOEFF_NORMED)

        # Select rectangles with
        # confidence greater than threshold
        (y_points, x_points) = np.where(match >= thresh)
        (y2_points, x2_points) = np.where(match2 >= thresh)
        if len(y2_points) > len(y_points):
            (y_points, x_points) = (y2_points, x2_points)
        # initialize our list of rectangles
        boxes = list()

        # loop over the starting (x, y)-coordinates again
        for (x, y) in zip(x_points, y_points):
            
            # update our list of rectangles
            boxes.append((x, y, x + W, y + H))
        # apply non-maxima suppression to the rectangles
        # this will create a single bounding box
        boxes = non_max_suppression(np.array(boxes))
        # loop over the final bounding boxes
        for (x1, y1, x2, y2) in boxes:        
            # draw the bounding box on the image
            cv2.rectangle(rotated, (x1, y1), (x2, y2),(255, 0, 0), 3)
        # Show the template and the final output
        if len(boxes)==0:
                cv2.putText(img=rotated, text='Broken', org=(10, 100), fontFace=cv2.FONT_HERSHEY_TRIPLEX, fontScale=1, color=(0, 0, 255),thickness=3)
        else:
                cv2.putText(img=rotated, text='Ok', org=(10, 100), fontFace=cv2.FONT_HERSHEY_TRIPLEX, fontScale=1, color=(0, 255, 0),thickness=3)
        cv2.imshow("Fuse",original_image)
        cv2.waitKey(500)
        cv2.imshow("Result", rotated)
        cv2.waitKey(1000)

def loadimage():
    imgpath = r"D:\AbhiPy\CS50FinalProject\Fuse\temp\mainimage2.bmp"
    img_rgb = cv2.imread(imgpath)
    cv2.imshow('First Image', img_rgb)
    cv2.waitKey(5000)


if __name__ == "__main__":
    main()